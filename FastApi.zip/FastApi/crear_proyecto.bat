@echo off
setlocal EnableDelayedExpansion

:: ========================================
:: VALIDAR ARGUMENTO
:: ========================================
if "%~1"=="" (
    echo.
    echo ========================================
    echo  ERROR
    echo ========================================
    echo.
    echo  Debes indicar la ruta de tu carpeta Three.js.
    echo.
    echo  Ejemplos:
    echo    crear_proyecto.bat "C:\Users\Alumno\Desktop\AnimacionAR"
    echo    crear_proyecto.bat "E:\MiUSB\AnimacionAR"
    echo    crear_proyecto.bat "D:\Proyectos\AnimacionAR"
    echo.
    pause
    exit /b 1
)

set "RUTA_THREE=%~1"

:: Verificar que la carpeta existe
if not exist "%RUTA_THREE%\" (
    echo.
    echo ERROR: La carpeta no existe:
    echo %RUTA_THREE%
    echo.
    pause
    exit /b 1
)

:: ========================================
:: CONFIGURACION
:: ========================================
set "NOMBRE_PROYECTO=mi_proyecto_fastapi"
set "RUTA_COMPLETA=%CD%\%NOMBRE_PROYECTO%"
set "RUTA_VENV=%RUTA_COMPLETA%\venv"
set "RUTA_DESTINO=%RUTA_COMPLETA%\static"

echo ========================================
echo  CREANDO PROYECTO FASTAPI + THREE.JS
echo ========================================
echo.
echo Origen Three.js : %RUTA_THREE%
echo Destino proyecto: %RUTA_COMPLETA%
echo.

:: ========================================
:: 1. CREAR CARPETA DEL PROYECTO
:: ========================================
echo [1/8] Creando carpeta del proyecto...
if not exist "%RUTA_COMPLETA%" (
    mkdir "%RUTA_COMPLETA%"
    echo    OK: Carpeta creada.
) else (
    echo    La carpeta ya existe. Continuando...
)

:: ========================================
:: 2. CREAR ENTORNO VIRTUAL
:: ========================================
echo [2/8] Creando entorno virtual...
python -m venv "%RUTA_VENV%"
if errorlevel 1 (
    echo ERROR: No se pudo crear el entorno virtual.
    echo Asegurate de tener Python instalado y en el PATH.
    pause
    exit /b 1
)
echo    OK: Entorno virtual creado.

:: ========================================
:: 3. ACTIVAR ENTORNO VIRTUAL
:: ========================================
echo [3/8] Activando entorno virtual...
call "%RUTA_VENV%\Scripts\activate.bat"
echo    OK: Entorno activado.

:: ========================================
:: 4. INSTALAR FASTAPI
:: ========================================
echo [4/8] Instalando FastAPI y dependencias...
pip install "fastapi[standard]"
if errorlevel 1 (
    echo ERROR: Fallo la instalacion.
    pause
    exit /b 1
)
echo    OK: Instalacion completa.

:: ========================================
:: 5. CREAR main.py
:: ========================================
echo [5/8] Creando main.py...
(
echo from fastapi import FastAPI
echo from fastapi.staticfiles import StaticFiles
echo.
echo app = FastAPI^(^)
echo.
echo @app.get^("/api"^)
echo def read_root^(^):
echo     return {"message": "API de FastAPI + Three.js funcionando"}
echo.
echo app.mount^("/", StaticFiles^(directory="static", html=True^), name="static"^)
) > "%RUTA_COMPLETA%\main.py"
echo    OK: main.py creado.

:: ========================================
:: 6. CREAR CARPETA static
:: ========================================
echo [6/8] Creando carpeta static...
mkdir "%RUTA_DESTINO%"

:: ========================================
:: 7. COPIAR ARCHIVOS THREE.JS
:: ========================================
echo [7/8] Copiando archivos de Three.js...

echo    Copiando build...
xcopy "%RUTA_THREE%\build" "%RUTA_DESTINO%\build\" /E /I /Y /Q

echo    Copiando jsm...
xcopy "%RUTA_THREE%\jsm" "%RUTA_DESTINO%\jsm\" /E /I /Y /Q

echo    Copiando models...
xcopy "%RUTA_THREE%\models" "%RUTA_DESTINO%\models\" /E /I /Y /Q

echo    Copiando textures...
xcopy "%RUTA_THREE%\textures" "%RUTA_DESTINO%\textures\" /E /I /Y /Q

echo    Copiando archivos sueltos...
copy "%RUTA_THREE%\index.html" "%RUTA_DESTINO%\index.html" >nul
copy "%RUTA_THREE%\main.css" "%RUTA_DESTINO%\main.css" >nul
copy "%RUTA_THREE%\files.json" "%RUTA_DESTINO%\files.json" >nul
copy "%RUTA_THREE%\tags.json" "%RUTA_DESTINO%\tags.json" >nul
echo    OK: Archivos copiados.

:: ========================================
:: 8. INICIAR SERVIDOR
:: ========================================
echo [8/8] Iniciando servidor Uvicorn...
echo.
echo ========================================
echo  SERVIDOR LISTO
echo ========================================
echo.
echo  Three.js:  http://127.0.0.1:8000
echo  API:       http://127.0.0.1:8000/api
echo  Docs API:  http://127.0.0.1:8000/docs
echo.
echo  Presiona Ctrl+C para detener
echo ========================================
echo.

uvicorn --app-dir "%RUTA_COMPLETA%" main:app --reload

:: ========================================
:: AL DETENER
:: ========================================
echo.
echo Servidor detenido.
deactivate
echo Entorno virtual desactivado.
pause