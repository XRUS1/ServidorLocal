@echo off
setlocal

:: ========================================
:: INICIAR SERVIDOR FASTAPI + THREE.JS
:: Usar este todos los dias
:: ========================================

set "RUTA_COMPLETA=%CD%\mi_proyecto_fastapi"
set "RUTA_VENV=%RUTA_COMPLETA%\venv"

echo ========================================
echo  INICIANDO SERVIDOR FASTAPI + THREE.JS
echo ========================================
echo.

:: Verificar que exista el entorno virtual
if not exist "%RUTA_VENV%\Scripts\activate.bat" (
    echo.
    echo ========================================
    echo  ERROR
    echo ========================================
    echo.
    echo  No se encontro el entorno virtual.
    echo.
    echo  Ejecuta primero:
    echo    crear_proyecto.bat "ruta\de\tu\AnimacionAR"
    echo.
    pause
    exit /b 1
)

:: Activar entorno virtual
echo Activando entorno virtual...
call "%RUTA_VENV%\Scripts\activate.bat"
echo OK: Entorno activado.
echo.

:: Iniciar servidor
echo ========================================
echo  SERVIDOR LISTO
echo ========================================
echo.
echo  Three.js : http://127.0.0.1:8000
echo  API      : http://127.0.0.1:8000/api
echo  Docs API : http://127.0.0.1:8000/docs
echo.
echo  Presiona Ctrl+C para detener
echo ========================================
echo.

uvicorn --app-dir "%RUTA_COMPLETA%" main:app --reload

:: Al detener el servidor
echo.
echo Servidor detenido.
deactivate
echo Entorno virtual desactivado.
pause