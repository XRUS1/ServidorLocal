QUERETAFLARE v2.2 - Instrucciones
===================================

ARCHIVOS:
  iniciar_queretaflare.bat  -> Lanzador (doble clic)
  queretaflare.py           -> Motor principal

INSTALACION:
  1. Copia AMBOS archivos a la carpeta raiz de tu materia,
     al mismo nivel que "Clase_WEBXR".

     Ejemplo:
     D:\Diseno Interactivo 2 Sem 2025\
         ├── Clase_WEBXR\
         │   ├── main.py
         │   ├── Equipo01\
         │   │   ├── proy01\
         │   │   └── proy02
         │   └── Equipo02\
         ├── MiThreeJS\
         ├── iniciar_queretaflare.bat   <-- AQUI
         └── queretaflare.py            <-- AQUI

  2. Doble clic en "iniciar_queretaflare.bat"

REQUISITOS:
  - Python instalado (3.8 o superior)
  - FastAPI y Uvicorn:
      pip install fastapi uvicorn
  - cloudflared instalado y en el PATH:
      https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/

QUE HACE:
  - Verifica que tengas todo instalado.
  - Limpia procesos viejos.
  - Genera index.html automaticamente.
  - Levanta FastAPI en localhost:8000.
  - Abre tunel Cloudflare con HTTPS gratuito.
  - Muestra la URL y abre un QR automatico.
  - Al cerrar, limpia todo (restaura DNS si es modo 2).

MODO SIMPLE vs MODO UNIVERSIDAD:
  - Modo Simple (1): Funciona en casa y en la mayoria de redes.
  - Modo Universidad (2): Solo si el Modo 1 falla. Pide Admin y
    cambia temporalmente el DNS a 1.1.1.1. Al cerrar, restaura
    tu DNS original automaticamente.

CORRECCIONES EN v2.2:
  - run() usa encoding='cp850' + errors='ignore' para evitar
    que netsh rompa el script con acentos en Windows en espanol.
  - Modo Universidad reinicia el archivo .bat original (no el .py
    suelto) para conservar las rutas del proyecto al elevar privilegios.
  - Deteccion de DNS valida que el valor no sea texto decorativo.
  - Cierre seguro del archivo log antes de matar procesos.
