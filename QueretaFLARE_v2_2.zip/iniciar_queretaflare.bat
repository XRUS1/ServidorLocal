@echo off
setlocal
cd /d "%~dp0"
python queretaflare.py
pause
