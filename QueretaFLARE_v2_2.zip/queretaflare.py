import os
import sys
import subprocess
import time
import re
import webbrowser
import ctypes
import tempfile

# ============================================
# VARIABLES GLOBALES PARA LIMPIEZA SEGURA
# ============================================
_g_modo = 1
_g_dns_info = None
_g_fastapi_proc = None
_g_cf_proc = None
_g_cf_log_file = None

# ============================================
# UTILIDADES
# ============================================
def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def run(cmd, capture=True):
    # CORRECCION: encoding='cp850' + errors='ignore' para que netsh y comandos
    # nativos de Windows no rompan el script con acentos o caracteres especiales.
    result = subprocess.run(
        cmd,
        shell=True,
        capture_output=capture,
        text=True,
        encoding='cp850',
        errors='ignore'
    )
    return result.stdout.strip() if capture else ""

def kill_process(proc, name="proceso"):
    if proc is None:
        return
    try:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
    except Exception as e:
        print(f"  [WARN] No se pudo terminar {name}: {e}")

def title(t):
    os.system(f'title {t}')

def clear():
    os.system('cls')

def pause():
    input('\n  Presiona Enter para continuar...')

# ============================================
# CONFIGURACION
# ============================================
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
RUTA_PROYECTO = os.path.join(SCRIPT_DIR, 'Clase_WEBXR')
TEMP_LOG = os.path.join(tempfile.gettempdir(), f'queretaflare_cf_{os.getpid()}.log')

# ============================================
# VERIFICAR DEPENDENCIAS
# ============================================
def verificar_dependencias():
    print('  [INFO] Verificando dependencias...')

    try:
        subprocess.run(['uvicorn', '--version'], capture_output=True, check=True)
    except (FileNotFoundError, subprocess.CalledProcessError):
        print('  [ERROR] uvicorn no encontrado.')
        print('  Instala con: pip install uvicorn')
        pause()
        sys.exit(1)

    try:
        subprocess.run(['cloudflared', '--version'], capture_output=True, check=True)
    except (FileNotFoundError, subprocess.CalledProcessError):
        print('  [ERROR] cloudflared no encontrado.')
        print('  Descarga desde:')
        print('  https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/')
        pause()
        sys.exit(1)

    print('  [OK] Todas las dependencias listas.')
    print()

# ============================================
# BANNER
# ============================================
def banner():
    clear()
    print()
    print('  ========================================================')
    print('   QUERETAFLARE - Servidor WebXR para Clase')
    print('   FastAPI + Cloudflare Tunnel (Gratis y Seguro)')
    print('  ========================================================')
    print()

# ============================================
# LIMPIEZA INICIAL
# ============================================
def limpieza_inicial():
    global _g_cf_log_file

    print('  [INFO] Limpiando procesos anteriores...')

    subprocess.run('taskkill /im cloudflared.exe /f >nul 2>&1', shell=True)
    subprocess.run('taskkill /im uvicorn.exe /f >nul 2>&1', shell=True)
    subprocess.run('taskkill /fi "windowtitle eq FastAPI - Servidor WebXR*" /f >nul 2>&1', shell=True)

    if _g_cf_log_file:
        try:
            _g_cf_log_file.close()
        except:
            pass
        _g_cf_log_file = None

    if os.path.exists(TEMP_LOG):
        try:
            os.remove(TEMP_LOG)
        except:
            pass

    time.sleep(1)
    print('  [OK] Listo.')
    print()

# ============================================
# VERIFICAR PROYECTO
# ============================================
def verificar_proyecto():
    if not os.path.exists(os.path.join(RUTA_PROYECTO, 'main.py')):
        print('  [ERROR] No se encontro el proyecto en:')
        print(f'  {RUTA_PROYECTO}')
        print()
        print('  Verifica que la carpeta Clase_WEBXR exista')
        print('  y que contenga el archivo main.py')
        print()
        pause()
        sys.exit(1)
    print(f'  [OK] Proyecto: {RUTA_PROYECTO}')
    print()

# ============================================
# GENERAR index.html DINAMICO
# ============================================
def generar_index():
    print('  [INFO] Generando index.html dinamico...')

    html = '''<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QueretaFLARE - Clase WebXR</title>
    <style>
        body { font-family: Arial, sans-serif; background: #1a1a2e; color: #fff; text-align: center; padding: 20px; }
        h1 { color: #e94560; }
        .grupo { margin: 20px 0; padding: 15px; background: #0f0f1a; border-radius: 15px; }
        .grupo h2 { color: #0f3460; margin-bottom: 10px; }
        .proyecto { display: inline-block; margin: 5px; padding: 10px 20px; background: #1f4068; border-radius: 8px; text-decoration: none; color: #fff; }
        .proyecto:hover { background: #e94560; }
    </style>
</head>
<body>
    <h1>QueretaFLARE - Selecciona tu Equipo</h1>
'''

    equipos = [d for d in os.listdir(RUTA_PROYECTO)
               if os.path.isdir(os.path.join(RUTA_PROYECTO, d)) and d.startswith('Equipo')]
    equipos.sort()

    for equipo in equipos:
        html += f'    <div class="grupo">\n        <h2>{equipo}</h2>\n'
        equipo_path = os.path.join(RUTA_PROYECTO, equipo)
        proyectos = [d for d in os.listdir(equipo_path)
                     if os.path.isdir(os.path.join(equipo_path, d)) and d.startswith('proy')]
        proyectos.sort()
        if proyectos:
            for proy in proyectos:
                html += f'        <a href="/{equipo}/{proy}/" class="proyecto">{proy}</a>\n'
        else:
            html += '        <p style="color:#666;">(Sin proyectos aun)</p>\n'
        html += '    </div>\n'

    html += '''</body>
</html>'''

    with open(os.path.join(RUTA_PROYECTO, 'index.html'), 'w', encoding='utf-8') as f:
        f.write(html)

    print('  [OK] index.html actualizado.')
    print()

# ============================================
# MENU
# ============================================
def menu():
    print('  Selecciona modo de inicio:')
    print()
    print('   [1] Modo Simple  - Sin cambiar DNS (recomendado)')
    print('       Ideal si la universidad no bloquea Cloudflare.')
    print()
    print('   [2] Modo Universidad - Admin + DNS 1.1.1.1')
    print('       Usa esto SOLO si el Modo 1 falla tras 30 seg.')
    print()
    while True:
        opcion = input('   Elige opcion (1 o 2): ').strip()
        if opcion in ('1', '2'):
            return int(opcion)
        print('   Opcion invalida. Intenta de nuevo.')

# ============================================
# MODO UNIVERSIDAD (CORREGIDO)
# ============================================
def modo_universidad():
    global _g_dns_info

    if not is_admin():
        print()
        print('  [INFO] Reiniciando como Administrador de forma segura...')
        time.sleep(2)

        # CORRECCION: En lugar de relanzar el .py aislado, buscamos el archivo
        # .bat original para conservar las rutas del proyecto intactas.
        bat_principal = os.path.join(SCRIPT_DIR, "iniciar_queretaflare.bat")

        if os.path.exists(bat_principal):
            ctypes.windll.shell32.ShellExecuteW(None, 'runas', bat_principal, None, None, 1)
        else:
            # Respaldo si no encuentra el .bat
            ctypes.windll.shell32.ShellExecuteW(None, 'runas', sys.executable, f'"{__file__}"', None, 1)

        sys.exit(0)

    print('  [MODO UNIVERSIDAD] Detectando interfaz de red...')

    # PowerShell robusto para aislar la interfaz conectada
    ps_cmd = 'powershell -Command "Get-NetAdapter | Where-Object { $_.Status -eq \'Up\' } | Select-Object -First 1 -ExpandProperty Name"'
    interfaz = run(ps_cmd).strip()

    if not interfaz:
        print('  [ERROR] No se detecto interfaz de red activa.')
        print('  Asegurate de tener una conexion Ethernet o WiFi activa.')
        pause()
        sys.exit(1)

    print(f'  [OK] Interfaz: {interfaz}')

    # Guardar DNS original mapeando tanto espanol como ingles de forma segura
    dns_old = 'DHCP'
    try:
        dns_output = run(f'netsh interface ip show dns "{interfaz}"')
        for line in dns_output.split('\n'):
            if any(x in line for x in ['Servidores DNS', 'DNS servers', 'Configurac']) and ':' in line:
                parts = line.split(':', 1)
                if len(parts) > 1:
                    val = parts[1].strip()
                    # Validamos que sea una IP legitima y no texto decorativo
                    if val and not val.isalpha():
                        dns_old = val
                        break
    except Exception as e:
        print(f'  [WARN] No se pudo leer DNS actual: {e}')

    print(f'  [INFO] DNS original registrado: {dns_old}')

    # Cambiar DNS con salida limpia
    try:
        run(f'netsh interface ip set dns name="{interfaz}" static 1.1.1.1 primary', capture=False)
        run(f'netsh interface ip add dns name="{interfaz}" 1.0.0.1 index=2', capture=False)
        print('  [OK] DNS cambiado exitosamente a 1.1.1.1 / 1.0.0.1')
    except Exception as e:
        print(f'  [ERROR] No se pudo cambiar DNS: {e}')
        pause()
        sys.exit(1)

    print()
    _g_dns_info = (interfaz, dns_old)
    return interfaz, dns_old

# ============================================
# FASTAPI
# ============================================
def lanzar_fastapi():
    global _g_fastapi_proc

    print('  [1/3] Lanzando FastAPI...')
    _g_fastapi_proc = subprocess.Popen(
        ['uvicorn', 'main:app', '--host', '0.0.0.0', '--port', '8000'],
        cwd=RUTA_PROYECTO,
        creationflags=subprocess.CREATE_NEW_CONSOLE
    )
    time.sleep(3)
    print('  [OK] FastAPI listo.')
    print()
    return _g_fastapi_proc

# ============================================
# CLOUDFLARE
# ============================================
def lanzar_cloudflare():
    global _g_cf_proc, _g_cf_log_file

    print('  [2/3] Abriendo tunel HTTPS con Cloudflare...')
    print('  (Esto puede tardar 5-10 segundos...)')

    if os.path.exists(TEMP_LOG):
        try:
            os.remove(TEMP_LOG)
        except:
            pass

    _g_cf_log_file = open(TEMP_LOG, 'w')
    _g_cf_proc = subprocess.Popen(
        ['cloudflared', 'tunnel', '--url', 'http://localhost:8000'],
        stdout=_g_cf_log_file,
        stderr=subprocess.STDOUT,
        creationflags=subprocess.CREATE_NEW_CONSOLE
    )
    return _g_cf_proc, _g_cf_log_file

# ============================================
# ESPERAR URL
# ============================================
def esperar_url():
    print('  [3/3] Esperando URL segura...')

    for intento in range(30):
        time.sleep(1)

        if not os.path.exists(TEMP_LOG):
            continue

        try:
            with open(TEMP_LOG, 'r', encoding='utf-8', errors='ignore') as f:
                contenido = f.read()
        except:
            continue

        match = re.search(r'https://[a-zA-Z0-9\-]+\.trycloudflare\.com', contenido)
        if match:
            return match.group(0)

    return None

# ============================================
# MOSTRAR RESULTADO
# ============================================
def mostrar_resultado(url):
    print()
    print('  ========================================================')
    print('   ENTORNO LISTO - QUERETAFLARE')
    print('  ========================================================')
    print(f'   URL para tus alumnos:')
    print(f'   {url}')
    print('  ========================================================')
    print()
    print('  [OK] Generando codigo QR...')
    webbrowser.open(f'https://api.qrserver.com/v1/create-qr-code/?size=400x400&data={url}')
    print()

# ============================================
# LIMPIEZA FINAL
# ============================================
def limpieza_final():
    global _g_modo, _g_dns_info, _g_fastapi_proc, _g_cf_proc, _g_cf_log_file

    print()
    print('  Cerrando servicios...')

    # Restaurar DNS si estaba en modo 2
    if _g_modo == 2 and _g_dns_info:
        interfaz, dns_old = _g_dns_info
        print(f'  [INFO] Restaurando DNS original: {dns_old}...')
        try:
            if dns_old.upper() == 'DHCP':
                run(f'netsh interface ip set dns name="{interfaz}" dhcp', capture=False)
            else:
                run(f'netsh interface ip set dns name="{interfaz}" static {dns_old} primary', capture=False)
            print('  [OK] DNS restaurado.')
        except Exception as e:
            print(f'  [WARN] No se pudo restaurar DNS: {e}')

    # CORRECCION: Cerrar archivo log ANTES de matar el proceso para evitar
    # que Windows bloquee el archivo al intentar borrarlo despues.
    if _g_cf_log_file:
        try:
            _g_cf_log_file.close()
        except:
            pass
        _g_cf_log_file = None

    # Cerrar procesos por PID
    kill_process(_g_cf_proc, 'Cloudflare Tunnel')
    kill_process(_g_fastapi_proc, 'FastAPI')

    # Borrar log temporal
    if os.path.exists(TEMP_LOG):
        try:
            os.remove(TEMP_LOG)
        except:
            pass

    print('  [OK] Todo cerrado. Hasta la proxima clase, maestro.')
    time.sleep(2)

# ============================================
# MAIN
# ============================================
def main():
    global _g_modo

    title('QueretaFLARE - Servidor WebXR')
    banner()

    verificar_dependencias()
    limpieza_inicial()
    verificar_proyecto()
    generar_index()

    _g_modo = menu()

    if _g_modo == 2:
        modo_universidad()

    print(f'  [OK] Modo seleccionado: {_g_modo}')
    print()

    lanzar_fastapi()
    lanzar_cloudflare()

    url = esperar_url()

    if url:
        mostrar_resultado(url)
        input('  Presiona Enter cuando termine la clase para cerrar todo...')
    else:
        print()
        print('  [ERROR] Cloudflare no respondio en 30 segundos.')
        print()
        if _g_modo == 1:
            print('  [SUGERENCIA] Prueba de nuevo eligiendo [2] Modo Universidad.')
            print('  Es posible que el firewall bloquee la resolucion DNS de Cloudflare.')
        else:
            print('  [SUGERENCIA] Incluso con DNS 1.1.1.1 no funciono.')
            print('  El firewall podria bloquear cloudflared por completo.')
        print()
        pause()

    limpieza_final()

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\n  [INFO] Interrumpido por el usuario.')
        limpieza_final()
    except Exception as e:
        print(f'\n  [ERROR] {e}')
        limpieza_final()
        pause()
